-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2025-02-11 22:00:23
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `test`
--

-- --------------------------------------------------------

--
-- 表的结构 `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- 表的结构 `elderly`
--

CREATE TABLE `elderly` (
  `id` int(11) NOT NULL,
  `Elderly_ID` int(20) NOT NULL,
  `Elderly_Name` varchar(50) NOT NULL,
  `Elderly_Age` int(20) NOT NULL,
  `Elderly_Contact` varchar(20) NOT NULL,
  `Elderly_Guardian` varchar(50) NOT NULL,
  `Guardian_Contact` varchar(20) NOT NULL,
  `Healthy_Status` enum('Healthy','Unhealthy') NOT NULL,
  `Image_File` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- 转存表中的数据 `elderly`
--

INSERT INTO `elderly` (`id`, `Elderly_ID`, `Elderly_Name`, `Elderly_Age`, `Elderly_Contact`, `Elderly_Guardian`, `Guardian_Contact`, `Healthy_Status`, `Image_File`) VALUES
(13, 4, 'Chan Toh Pat', 67, '0173456789', 'Tan Yi Xuan', '0174797848', 'Healthy', 'image/elderly.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `medical_record_data`
--

CREATE TABLE `medical_record_data` (
  `record_id` int(11) NOT NULL,
  `elderly_name` varchar(255) NOT NULL,
  `family_medical_history` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `doctor_note` varchar(255) NOT NULL,
  `vital_sign` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `observation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- 转存表中的数据 `medical_record_data`
--

INSERT INTO `medical_record_data` (`record_id`, `elderly_name`, `family_medical_history`, `date`, `doctor_note`, `vital_sign`, `height`, `weight`, `observation`) VALUES
(4, 'Chan Toh Pat', 'None', '2025-02-12', 'Do some exercise like jogging', '60/30 mm Hg', '1.58 m', '66 kg', 'Still good');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `User_ID` int(20) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Age` int(20) NOT NULL,
  `Gender` enum('Male','Female') NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Role` enum('elderly','admin','consultant','guardian') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `User_ID`, `Username`, `Password`, `Age`, `Gender`, `Email`, `Address`, `Phone`, `Role`) VALUES
(1, 0, 'Sim Yi Jie', '123', 21, 'Male', 'simyijie2004@gmail.com', 'No 88, Taman Indah Wang, 71010 Lukut, Port Dickson', '0176610307', 'admin'),
(38, 1, 'Chan Toh Pat', '234', 67, 'Male', 'chantohpat@gmail.com', 'No 50, Taman Indah Baru', '0173456789', 'elderly'),
(39, 3, 'Yap Shern Yu', '123', 31, 'Male', 'yapshernyu2004@gmail.com', 'No 45, Taman Indah Jaya', '0133339389', 'consultant'),
(40, 4, 'Tan Yi Xuan', '123', 24, 'Female', 'tanyixuan2004@gmail.com', 'No 34, Taman Jaya', '0174797848', 'guardian');

--
-- 转储表的索引
--

--
-- 表的索引 `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `elderly`
--
ALTER TABLE `elderly`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `medical_record_data`
--
ALTER TABLE `medical_record_data`
  ADD PRIMARY KEY (`record_id`);

--
-- 表的索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- 使用表AUTO_INCREMENT `elderly`
--
ALTER TABLE `elderly`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
